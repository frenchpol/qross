import { useState, useCallback, useEffect } from 'react';
import { toast } from 'sonner';
import { GEOLOCATION } from '@/constants/map';
import type { GeolocationConfig, GeolocationState, GeolocationHandlers } from '@/types/geolocation';
import { validatePosition, extractCoordinates, handleLocationError, getGeolocationOptions } from '@/utils/location';

const DEFAULT_CONFIG: GeolocationConfig = GEOLOCATION;

export const useGeolocation = (config: Partial<GeolocationConfig> = {}) => {
  const [state, setState] = useState<GeolocationState>({
    isTracking: false,
    isPaused: false,
    error: null,
    isLoading: false
  });
  const [watchId, setWatchId] = useState<number | null>(null);
  const [handlers, setHandlers] = useState<GeolocationHandlers | null>(null);

  const mergedConfig = { ...DEFAULT_CONFIG, ...config };

  const getCurrentPosition = useCallback(async (handlers: GeolocationHandlers) => {
    const { onSuccess, onError, onStateChange } = handlers;

    if (!navigator.geolocation) {
      const error = new Error('Geolocation is not supported');
      handleLocationError(error);
      return;
    }

    setState(prev => ({ ...prev, isLoading: true }));
    onStateChange?.({ ...state, isLoading: true });

    let attempt = 1;
    const tryGetPosition = () => {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          if (!validatePosition(position)) {
            const error = new Error('Invalid position data');
            handleLocationError(error);
            return;
          }
          setState(prev => ({ ...prev, isLoading: false, error: null }));
          onStateChange?.({ ...state, isLoading: false, error: null });
          onSuccess(position);
        },
        (error) => {
          if (error.code === error.TIMEOUT && attempt < mergedConfig.retryAttempts) {
            attempt++;
            setTimeout(tryGetPosition, mergedConfig.retryDelay);
          } else {
            handleLocationError(error);
            setState(prev => ({ ...prev, isLoading: false, error }));
            onStateChange?.({ ...state, isLoading: false, error });
            onError(error);
          }
        },
        getGeolocationOptions(attempt)
      );
    };

    tryGetPosition();
  }, [mergedConfig, state]);

  const startTracking = useCallback((handlers: GeolocationHandlers) => {
    const { onSuccess, onError, onStateChange } = handlers;
    setHandlers(handlers);

    if (!navigator.geolocation) {
      const error = new Error('Geolocation is not supported');
      handleLocationError(error);
      return;
    }

    setState(prev => ({ ...prev, isTracking: true, isLoading: true }));
    onStateChange?.({ ...state, isTracking: true, isLoading: true });

    const id = navigator.geolocation.watchPosition(
      (position) => {
        if (!validatePosition(position)) {
          const error = new Error('Invalid position data');
          handleLocationError(error);
          return;
        }
        setState(prev => ({ ...prev, isLoading: false, error: null }));
        onStateChange?.({ ...state, isLoading: false, error: null });
        onSuccess(position);
      },
      (error) => {
        handleLocationError(error);
        setState(prev => ({ ...prev, isLoading: false, error }));
        onStateChange?.({ ...state, isLoading: false, error });
        onError(error);
      },
      getGeolocationOptions()
    );

    setWatchId(id);
    toast.success('Début de l\'enregistrement');
  }, [state]);

  const pauseTracking = useCallback(() => {
    if (watchId !== null) {
      navigator.geolocation.clearWatch(watchId);
      setWatchId(null);
    }
    setState(prev => ({ ...prev, isPaused: true }));
    toast.info('Enregistrement en pause');
  }, [watchId]);

  const resumeTracking = useCallback(() => {
    if (handlers) {
      startTracking(handlers);
    }
    setState(prev => ({ ...prev, isPaused: false }));
    toast.success('Reprise de l\'enregistrement');
  }, [handlers, startTracking]);

  const stopTracking = useCallback(() => {
    if (watchId !== null) {
      navigator.geolocation.clearWatch(watchId);
      setWatchId(null);
    }
    setHandlers(null);
    setState(prev => ({ 
      ...prev, 
      isTracking: false,
      isPaused: false
    }));
    toast.success('Fin de l\'enregistrement');
  }, [watchId]);

  useEffect(() => {
    return () => {
      if (watchId !== null) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  }, [watchId]);

  return {
    ...state,
    getCurrentPosition,
    startTracking,
    stopTracking,
    pauseTracking,
    resumeTracking
  };
};