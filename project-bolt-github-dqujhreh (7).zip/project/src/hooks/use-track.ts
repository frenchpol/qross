import { useState, useCallback } from 'react';
import * as turf from '@turf/turf';
import { GEOLOCATION } from '@/constants/map';
import { resetLocationFilters } from '@/utils/location';
import type { PathPoint, POI } from '@/types/location';

export const useTrack = () => {
  const [currentPath, setCurrentPath] = useState<PathPoint[]>([]);
  const [currentLocation, setCurrentLocation] = useState<[number, number] | null>(null);
  const [currentAltitude, setCurrentAltitude] = useState<number | null>(null);
  const [pois, setPois] = useState<POI[]>([]);
  const [trackName, setTrackName] = useState('');
  const [lastRecordedTime, setLastRecordedTime] = useState(0);
  const [lastPausePoint, setLastPausePoint] = useState<PathPoint | null>(null);

  const updatePosition = useCallback((position: GeolocationPosition, isPaused: boolean) => {
    const { latitude, longitude, altitude, accuracy } = position.coords;
    const newLocation: [number, number] = [longitude, latitude];
    const currentTime = Date.now();

    // Always update current position
    setCurrentLocation(newLocation);
    setCurrentAltitude(altitude);

    if (isPaused) {
      // Store the last point before pausing if we don't have one
      if (!lastPausePoint && currentPath.length > 0) {
        setLastPausePoint(currentPath[currentPath.length - 1]);
      }
      return;
    }

    let shouldAddPoint = currentPath.length === 0;

    // If we have a last pause point and this is the first position after resuming,
    // add both the last pause point and the current point to create a straight line
    if (lastPausePoint) {
      const newPoint: PathPoint = {
        coordinates: newLocation,
        altitude,
        timestamp: position.timestamp
      };
      
      // Add both points to create the straight line
      setCurrentPath(prev => [...prev, newPoint]);
      setLastPausePoint(null);
      setLastRecordedTime(currentTime);
      return;
    }

    if (!shouldAddPoint && currentPath.length > 0) {
      const lastPoint = currentPath[currentPath.length - 1].coordinates;
      const distance = turf.distance(
        turf.point(lastPoint),
        turf.point(newLocation),
        { units: 'meters' }
      );

      shouldAddPoint = 
        (distance > GEOLOCATION.DISTANCE_THRESHOLD && accuracy <= GEOLOCATION.ACCURACY_THRESHOLD) || 
        (currentTime - lastRecordedTime >= GEOLOCATION.UPDATE_INTERVAL * 3);
    }

    if (shouldAddPoint) {
      setLastRecordedTime(currentTime);
      const newPoint: PathPoint = {
        coordinates: newLocation,
        altitude,
        timestamp: position.timestamp
      };
      setCurrentPath(prev => [...prev, newPoint]);
    }
  }, [currentPath, lastRecordedTime, lastPausePoint]);

  const addPOI = useCallback((poi: POI) => {
    setPois(prev => [...prev, poi]);
  }, []);

  const resetTrack = useCallback(() => {
    setCurrentPath([]);
    setPois([]);
    setLastRecordedTime(0);
    setLastPausePoint(null);
    resetLocationFilters();
  }, []);

  return {
    currentPath,
    currentLocation,
    currentAltitude,
    pois,
    trackName,
    setTrackName,
    updatePosition,
    addPOI,
    resetTrack
  };
};